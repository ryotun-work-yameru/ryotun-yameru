<?php
mb_language('ja');
mb_internal_encoding('UTF-8');

$mailTo = "g031o002@s.iwate-pu.ac.jp";
$subject = mb_encode_mimeheader("吹奏楽サークルHP フォームから送信");
$from = "From:".$outputdata["mailNo"];

//送信メッセージ
$message = <<< EOD
以下の内容がフォームより送信されました。
────────────────────────────────────
[氏名]
{$outputdata["Name"]}

[メールアドレス]
{$outputdata["mailNo"]}

[メッセージ]
{$outputdata["message"]}
────────────────────────────────────
EOD;

$message = mb_convert_encoding($message , "ISO-2022-JP", "auto");
?>
